#include <stdio.h>
#include <stdlib.h>

/**
 * @param argc - the amount of arguments we received.
 * @param argv - the arguments from the user.
 * @return - returns 0 but output is prints.
 */
int main(int argc, char* argv[])
{
    if (argc != 2) //no inputs were given.
    {
        return 0;
    }
    int arg = atoi(argv[1]); //if a string is given converts to
    if (arg == 1)
    {
        printf("Hello, World!");
    }
    else if (arg == 2)
    {
        printf("Welcome to C!");
    }
    else //inputs is not 1 or 2 -> prints nothing.
    {

    }
    return 0;
}

